// ToastService.cs
// Equivalent to use-toast.ts + toast.tsx - a DI service for managing toast notifications.
// Register in Program.cs: builder.Services.AddScoped<ToastService>();

using Microsoft.AspNetCore.Components;

namespace YourApp.Components.UI;

public enum ToastVariant { Default, Destructive }

public class ToastModel
{
    public string Id { get; init; } = Guid.NewGuid().ToString();
    public string? Title { get; init; }
    public string? Description { get; init; }
    public ToastVariant Variant { get; init; } = ToastVariant.Default;
    public int DurationMs { get; init; } = 5000;
    public RenderFragment? Action { get; init; }
}

public class ToastService
{
    private readonly List<ToastModel> _toasts = [];

    public IReadOnlyList<ToastModel> Toasts => _toasts.AsReadOnly();

    public event Action? OnChange;

    public void Show(
        string? title = null,
        string? description = null,
        ToastVariant variant = ToastVariant.Default,
        int durationMs = 5000,
        RenderFragment? action = null)
    {
        var toast = new ToastModel
        {
            Title = title,
            Description = description,
            Variant = variant,
            DurationMs = durationMs,
            Action = action
        };
        _toasts.Add(toast);
        OnChange?.Invoke();

        // Auto-dismiss
        _ = AutoDismiss(toast.Id, durationMs);
    }

    public void Dismiss(string id)
    {
        _toasts.RemoveAll(t => t.Id == id);
        OnChange?.Invoke();
    }

    private async Task AutoDismiss(string id, int delayMs)
    {
        await Task.Delay(delayMs);
        Dismiss(id);
    }
}
