# Blazor UI Components
Conversão dos componentes shadcn/ui (React/Tailwind) para Blazor.

## Configuração

### 1. Copiar ficheiros
Copie todos os ficheiros `.razor` e `.cs` para a pasta `Components/UI/` do seu projeto.

### 2. CSS
Adicione o `components.css` ao seu projecto e referencie-o em `App.razor` ou `wwwroot/index.html`:
```html
<link rel="stylesheet" href="components.css" />
```

### 3. ToastService (DI)
Registe o serviço em `Program.cs`:
```csharp
builder.Services.AddScoped<ToastService>();
```

---

## Exemplos de Uso

### Tooltip
```razor
<Tooltip>
    <Trigger>
        <button>Pairar sobre mim</button>
    </Trigger>
    <Content>
        Esta é a dica de contexto.
    </Content>
</Tooltip>
```

---

### Table
```razor
<Table>
    <TableHeader>
        <TableRow>
            <TableHead>Nome</TableHead>
            <TableHead>Email</TableHead>
        </TableRow>
    </TableHeader>
    <TableBody>
        <TableRow>
            <TableCell>João Silva</TableCell>
            <TableCell>joao@exemplo.pt</TableCell>
        </TableRow>
    </TableBody>
    <TableFooter>
        <TableRow>
            <TableCell>Total</TableCell>
            <TableCell>1 utilizador</TableCell>
        </TableRow>
    </TableFooter>
</Table>
```

---

### Tabs
```razor
<Tabs DefaultValue="conta">
    <TabsList>
        <TabsTrigger Value="conta">Conta</TabsTrigger>
        <TabsTrigger Value="password">Password</TabsTrigger>
    </TabsList>
    <TabsContent Value="conta">
        <p>Definições da conta.</p>
    </TabsContent>
    <TabsContent Value="password">
        <p>Altere a sua password aqui.</p>
    </TabsContent>
</Tabs>
```

---

### Textarea
```razor
<Textarea @bind-Value="_texto"
          Placeholder="Escreva aqui..."
          Rows="5" />

@code {
    private string? _texto;
}
```

---

### Toast (Toaster + ToastService)
Coloque `<Toaster />` uma única vez em `MainLayout.razor`:
```razor
@* MainLayout.razor *@
<Toaster />
```

Dispare toasts em qualquer componente:
```razor
@inject ToastService Toast

<button @onclick="Mostrar">Mostrar notificação</button>

@code {
    void Mostrar() =>
        Toast.Show(
            title: "Guardado!",
            description: "As alterações foram guardadas com sucesso.");

    void MostrarErro() =>
        Toast.Show(
            title: "Erro",
            description: "Algo correu mal.",
            variant: ToastVariant.Destructive);
}
```

---

### Toggle
```razor
<Toggle @bind-Pressed="_ativo" Variant="outline">
    Negrito
</Toggle>

@code {
    private bool _ativo;
}
```

---

### ToggleGroup
```razor
<ToggleGroup Type="single" Variant="outline">
    <ToggleGroupItem Value="esquerda">Esq</ToggleGroupItem>
    <ToggleGroupItem Value="centro">Centro</ToggleGroupItem>
    <ToggleGroupItem Value="direita">Dir</ToggleGroupItem>
</ToggleGroup>
```

---

## Mapeamento React → Blazor

| Ficheiro React            | Blazor                                    |
|---------------------------|-------------------------------------------|
| `tooltip.tsx`             | `Tooltip.razor`                           |
| `table.tsx`               | `Table.razor` + `TableHeader/Body/Footer/Row/Head/Cell/Caption.razor` |
| `tabs.tsx`                | `Tabs.razor` + `TabsList/Trigger/Content.razor` |
| `textarea.tsx`            | `Textarea.razor`                          |
| `toast.tsx` + `use-toast.ts` | `ToastService.cs`                      |
| `toaster.tsx`             | `Toaster.razor`                           |
| `toggle.tsx`              | `Toggle.razor`                            |
| `toggle-group.tsx`        | `ToggleGroup.razor` + `ToggleGroupItem.razor` |

## Notas de Implementação

- **CascadingValue/CascadingParameter** substitui o Context API do React (`Tabs → TabsTrigger/TabsContent`, `ToggleGroup → ToggleGroupItem`).
- **ToastService** é um serviço Scoped em DI, substituindo o hook `useToast`.
- O CSS usa variáveis CSS (`--background`, `--foreground`, etc.) com os mesmos nomes dos tokens shadcn/ui — pode mapear directamente a partir do seu `tailwind.config`.
