# Blazor UI Components
Conversão de **shadcn/ui** (React/TSX) para **Blazor Web** (.razor).

## Estrutura
```
Components/UI/
├── Accordion.razor            Accordion, AccordionItem, AccordionTrigger, AccordionContent
├── Alert.razor                Alert, AlertTitle, AlertDescription
├── AlertDialog.razor          AlertDialog + 8 sub-componentes
├── AspectRatio.razor
├── Avatar.razor               Avatar, AvatarImage, AvatarFallback
├── Badge.razor
├── Breadcrumb.razor           Breadcrumb + 6 sub-componentes
├── Button.razor
├── Calendar.razor
├── Card.razor                 Card + 5 sub-componentes
├── Carousel.razor             Carousel + 5 sub-componentes
├── Checkbox.razor
├── Collapsible.razor          Collapsible, CollapsibleTrigger, CollapsibleContent
├── Command.razor              Command + 8 sub-componentes
├── ContextMenu.razor          ContextMenu + 13 sub-componentes
├── Dialog.razor               Dialog + 7 sub-componentes
├── Drawer.razor               Drawer + 7 sub-componentes
├── DropdownMenu.razor         DropdownMenu + 13 sub-componentes
└── Form.razor                 Form + 6 sub-componentes
```

## Pré-requisitos
- .NET 8 ou superior
- Tailwind CSS configurado no projeto (ou equivalente via CDN)

## Instalação
1. Copiar a pasta `Components/UI/` para o seu projeto Blazor.
2. Adicionar o namespace no `_Imports.razor`:
```razor
@using YourApp.Components.UI
```

## Exemplos de utilização

### Button
```razor
<Button Variant="Button.ButtonVariant.Outline" Size="Button.ButtonSize.Sm">
    Clique aqui
</Button>
```

### Accordion
```razor
<Accordion @bind-OpenItem="openSection">
    <AccordionItem Value="item-1">
        <AccordionTrigger>Secção 1</AccordionTrigger>
        <AccordionContent>Conteúdo da secção 1.</AccordionContent>
    </AccordionItem>
    <AccordionItem Value="item-2">
        <AccordionTrigger>Secção 2</AccordionTrigger>
        <AccordionContent>Conteúdo da secção 2.</AccordionContent>
    </AccordionItem>
</Accordion>

@code {
    private string? openSection;
}
```

### Alert
```razor
<Alert Variant="Alert.AlertVariant.Destructive">
    <AlertTitle>Erro</AlertTitle>
    <AlertDescription>Algo correu mal.</AlertDescription>
</Alert>
```

### AlertDialog
```razor
<AlertDialog @bind-Open="dialogOpen">
    <AlertDialogTrigger>
        <Button>Apagar</Button>
    </AlertDialogTrigger>
    <AlertDialogContent>
        <AlertDialogHeader>
            <AlertDialogTitle>Tem a certeza?</AlertDialogTitle>
            <AlertDialogDescription>Esta ação não pode ser desfeita.</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction OnClick="HandleConfirm">Confirmar</AlertDialogAction>
        </AlertDialogFooter>
    </AlertDialogContent>
</AlertDialog>

@code {
    private bool dialogOpen;
    private void HandleConfirm() { /* lógica */ }
}
```

### Avatar
```razor
<Avatar>
    <AvatarImage Src="/img/user.png" Alt="João Silva" />
    <AvatarFallback>JS</AvatarFallback>
</Avatar>
```

### Badge
```razor
<Badge Variant="Badge.BadgeVariant.Secondary">Novo</Badge>
```

### Breadcrumb
```razor
<Breadcrumb>
    <BreadcrumbList>
        <BreadcrumbItem>
            <BreadcrumbLink Href="/">Início</BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbSeparator />
        <BreadcrumbItem>
            <BreadcrumbPage>Produtos</BreadcrumbPage>
        </BreadcrumbItem>
    </BreadcrumbList>
</Breadcrumb>
```

### Calendar
```razor
<Calendar @bind-SelectedDate="selectedDate" ShowOutsideDays="true" />

@code {
    private DateTime? selectedDate;
}
```

### Card
```razor
<Card>
    <CardHeader>
        <CardTitle>Título</CardTitle>
        <CardDescription>Descrição do cartão.</CardDescription>
    </CardHeader>
    <CardContent>
        <p>Conteúdo principal.</p>
    </CardContent>
    <CardFooter>
        <Button>Ação</Button>
    </CardFooter>
</Card>
```

### Carousel
```razor
<Carousel>
    <CarouselContent>
        <CarouselItem><div class="p-4 border">Slide 1</div></CarouselItem>
        <CarouselItem><div class="p-4 border">Slide 2</div></CarouselItem>
        <CarouselItem><div class="p-4 border">Slide 3</div></CarouselItem>
    </CarouselContent>
    <CarouselPrevious />
    <CarouselNext />
</Carousel>
```

### Checkbox
```razor
<Checkbox @bind-Checked="isChecked" />

@code {
    private bool isChecked;
}
```

### Collapsible
```razor
<Collapsible @bind-Open="isOpen">
    <CollapsibleTrigger>
        <Button Variant="Button.ButtonVariant.Ghost">Mostrar mais</Button>
    </CollapsibleTrigger>
    <CollapsibleContent>
        <p>Conteúdo oculto.</p>
    </CollapsibleContent>
</Collapsible>

@code {
    private bool isOpen;
}
```

### Command
```razor
<Command>
    <CommandInput Placeholder="Pesquisar..." />
    <CommandList>
        <CommandEmpty>Sem resultados.</CommandEmpty>
        <CommandGroup Heading="Sugestões">
            <CommandItem OnSelect="() => Select("perfil")">
                Perfil
                <CommandShortcut>⌘P</CommandShortcut>
            </CommandItem>
            <CommandItem OnSelect="() => Select("definicoes")">Definições</CommandItem>
        </CommandGroup>
    </CommandList>
</Command>
```

### Dialog
```razor
<Dialog @bind-Open="dialogOpen">
    <DialogTrigger>
        <Button>Abrir</Button>
    </DialogTrigger>
    <DialogContent>
        <DialogHeader>
            <DialogTitle>Título do diálogo</DialogTitle>
            <DialogDescription>Descrição opcional.</DialogDescription>
        </DialogHeader>
        <p>Conteúdo do diálogo.</p>
        <DialogFooter>
            <DialogClose><Button Variant="Button.ButtonVariant.Outline">Fechar</Button></DialogClose>
        </DialogFooter>
    </DialogContent>
</Dialog>

@code {
    private bool dialogOpen;
}
```

### Drawer
```razor
<Drawer @bind-Open="drawerOpen">
    <DrawerTrigger>
        <Button>Abrir painel</Button>
    </DrawerTrigger>
    <DrawerContent>
        <DrawerHeader>
            <DrawerTitle>Painel lateral</DrawerTitle>
            <DrawerDescription>Conteúdo do painel.</DrawerDescription>
        </DrawerHeader>
        <div class="p-4">Corpo do painel.</div>
        <DrawerFooter>
            <DrawerClose><Button Variant="Button.ButtonVariant.Outline">Fechar</Button></DrawerClose>
        </DrawerFooter>
    </DrawerContent>
</Drawer>

@code {
    private bool drawerOpen;
}
```

### DropdownMenu
```razor
<DropdownMenu>
    <DropdownMenuTrigger>
        <Button Variant="Button.ButtonVariant.Outline">Opções</Button>
    </DropdownMenuTrigger>
    <DropdownMenuContent>
        <DropdownMenuLabel>Conta</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem OnClick="HandlePerfil">Perfil</DropdownMenuItem>
        <DropdownMenuItem OnClick="HandleDefinicoes">
            Definições
            <DropdownMenuShortcut>⌘S</DropdownMenuShortcut>
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem OnClick="HandleSair">Sair</DropdownMenuItem>
    </DropdownMenuContent>
</DropdownMenu>
```

### Form
```razor
<Form EditContext="editContext" OnValidSubmit="HandleSubmit">
    <DataAnnotationsValidator />
    <FormItem>
        <FormLabel FieldName="Nome">Nome</FormLabel>
        <FormControl FieldName="Nome">
            <InputText @bind-Value="model.Nome" class="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm" />
        </FormControl>
        <FormDescription>O seu nome completo.</FormDescription>
        <FormMessage FieldName="Nome" />
    </FormItem>
    <Button Type="submit">Submeter</Button>
</Form>

@code {
    private MyModel model = new();
    private EditContext editContext = default!;

    protected override void OnInitialized() => editContext = new(model);

    private void HandleSubmit(EditContext ctx) { /* guardar */ }

    public class MyModel
    {
        [Required] public string Nome { get; set; } = string.Empty;
    }
}
```

### AspectRatio
```razor
<AspectRatio Ratio="16.0/9.0" Class="bg-muted rounded-md overflow-hidden">
    <img src="/img/foto.jpg" alt="Foto" class="w-full h-full object-cover" />
</AspectRatio>
```

## Notas de conversão

| Conceito React/TSX | Equivalente Blazor |
|---|---|
| `React.forwardRef` | Parâmetros normais (sem `ref`) |
| `React.createContext` + `useContext` | `CascadingValue` + `[CascadingParameter]` |
| `useState` | campo + `StateHasChanged()` |
| `className` prop + `cn()` | `Class` param + interpolação de strings |
| Radix UI primitives | Lógica recriada nativamente |
| `data-[state=open]` | Condições `@if` / classes CSS condicionais |
| `asChild` (Slot) | Substituído por `ChildContent` simples |
| `react-hook-form` | `EditContext` + `DataAnnotationsValidator` |
| `embla-carousel` | Estado interno com `CurrentIndex` |
| `react-day-picker` | Calendário implementado com `DateTime` |
| `vaul` Drawer | Painel fixo com `@bind-Open` |
| `cmdk` Command | Componente com pesquisa por `SearchValue` |
