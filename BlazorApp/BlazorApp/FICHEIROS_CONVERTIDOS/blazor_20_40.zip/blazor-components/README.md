# shadcn/ui → Blazor Components

Conversão dos componentes shadcn/ui (React/TSX) para Blazor Web (.NET 8+).

## Componentes incluídos

| TSX original          | Blazor (.razor)                                               |
|-----------------------|---------------------------------------------------------------|
| `switch.tsx`          | `Switch.razor`                                                |
| `skeleton.tsx`        | `Skeleton.razor`                                              |
| `separator.tsx`       | `Separator.razor`                                             |
| `input.tsx`           | `Input.razor`                                                 |
| `label.tsx`           | `Label.razor`                                                 |
| `progress.tsx`        | `Progress.razor`                                              |
| `slider.tsx`          | `Slider.razor`                                                |
| `scroll-area.tsx`     | `ScrollArea.razor`                                            |
| `select.tsx`          | `Select.razor` + `SelectItem.razor`                           |
| `radio-group.tsx`     | `RadioGroup.razor` + `RadioGroupItem.razor`                   |
| `pagination.tsx`      | `Pagination.razor` + `PaginationContent/Item/Link/...razor`   |
| `hover-card.tsx`      | `HoverCard.razor`                                             |
| `popover.tsx`         | `Popover.razor`                                               |
| `sheet.tsx`           | `Sheet.razor` + `SheetHeader/Footer/Title/Description.razor`  |
| `resizable.tsx`       | `ResizablePanelGroup/Panel/Handle.razor`                      |
| `input-otp.tsx`       | `InputOTP/Group/Slot/Separator.razor`                         |
| `sonner.tsx`          | `Toaster.razor` + `Services/ToastService.cs`                  |
| `navigation-menu.tsx` | `NavigationMenu/List/Item/Trigger/Content/Link.razor`         |
| `menubar.tsx`         | `Menubar/Menu/Trigger/Content/Item/...razor`                  |
| `sidebar.tsx`         | `Sidebar*/SidebarProvider.razor` + `SidebarContext.cs`        |

---

## Instalação

1. Copia a pasta `Components/UI/` para o teu projeto Blazor.
2. Copia `Services/ToastService.cs` (necessário para o Toaster).
3. Ajusta o namespace em `SidebarContext.cs` e `ToastService.cs` conforme o teu projeto.

### Registar serviços em `Program.cs`

```csharp
using YourApp.Services;

builder.Services.AddScoped<IToastService, ToastService>();
```

### Adicionar `_Imports.razor`

Adiciona ao teu `_Imports.razor` o namespace dos componentes:

```razor
@using YourApp.Components.UI
@using YourApp.Services
```

### Toaster — colocar no layout

Em `MainLayout.razor`, adiciona o `<Toaster />` para que os toasts apareçam globalmente:

```razor
@inherits LayoutComponentBase

<div class="page">
    @Body
</div>

<Toaster />
```

---

## Exemplos de uso

### Switch
```razor
<Switch @bind-Checked="isEnabled" />
<Switch @bind-Checked="isEnabled" Disabled="true" />
```

### Input + Label
```razor
<Label For="email">Email</Label>
<Input id="email" Type="email" Placeholder="tu@exemplo.com" @bind-Value="email" />
```

### Progress
```razor
<Progress Value="@progress" />  @* 0-100 *@
```

### Select
```razor
<Select @bind-Value="selectedFruit">
    <SelectItem Value="apple">Maçã</SelectItem>
    <SelectItem Value="banana">Banana</SelectItem>
</Select>
```

### RadioGroup
```razor
<RadioGroup @bind-Value="option">
    <RadioGroupItem Value="a" /> Opção A
    <RadioGroupItem Value="b" /> Opção B
</RadioGroup>
```

### Pagination
```razor
<Pagination>
    <PaginationContent>
        <PaginationItem><PaginationPrevious Href="/page/1" /></PaginationItem>
        <PaginationItem><PaginationLink Href="/page/2" IsActive="true">2</PaginationLink></PaginationItem>
        <PaginationItem><PaginationNext Href="/page/3" /></PaginationItem>
    </PaginationContent>
</Pagination>
```

### Sheet (painel lateral)
```razor
<button @onclick="() => sheetOpen = true">Abrir</button>
<Sheet @bind-Open="sheetOpen" Side="right">
    <SheetHeader>
        <SheetTitle>Título</SheetTitle>
        <SheetDescription>Descrição do painel.</SheetDescription>
    </SheetHeader>
    <p>Conteúdo aqui.</p>
</Sheet>
@code { bool sheetOpen; }
```

### Popover
```razor
<Popover>
    <Trigger><button>Abrir popover</button></Trigger>
    <Content><p>Conteúdo do popover</p></Content>
</Popover>
```

### Toast (Sonner)
```razor
@inject IToastService Toast

<button @onclick="() => Toast.Success("Guardado!", "As alterações foram guardadas.")">
    Guardar
</button>
```

### Sidebar
```razor
<SidebarProvider>
    <Sidebar>
        <SidebarHeader>...</SidebarHeader>
        <SidebarContent>
            <SidebarGroup>
                <SidebarGroupLabel>Menu</SidebarGroupLabel>
                <SidebarGroupContent>
                    <SidebarMenu>
                        <SidebarMenuItem>
                            <SidebarMenuButton IsActive="true">
                                Home
                            </SidebarMenuButton>
                        </SidebarMenuItem>
                    </SidebarMenu>
                </SidebarGroupContent>
            </SidebarGroup>
        </SidebarContent>
        <SidebarRail />
    </Sidebar>
    <SidebarInset>
        <SidebarTrigger />
        <!-- conteúdo principal -->
    </SidebarInset>
</SidebarProvider>
```

---

## Notas sobre diferenças React → Blazor

| Conceito React               | Equivalente Blazor                          |
|------------------------------|---------------------------------------------|
| `useState`                   | Campo privado + `StateHasChanged()`         |
| `useContext` / Context API   | `[CascadingParameter]` + `<CascadingValue>` |
| `forwardRef`                 | `[Parameter]` normal (refs não necessários) |
| Radix UI Primitives          | HTML nativo + CSS classes                   |
| `cn()` (clsx/tailwind-merge) | `string.Join(" ", ...)` + `.Trim()`         |
| `next-themes`                | Atributo `data-theme` no `<html>` via JS    |
| Floating UI / Popper         | CSS `position: absolute` relativo ao pai    |
| `react-resizable-panels`     | CSS flex (drag completo requer JS Interop)  |
| `input-otp`                  | Implementação nativa Blazor                 |
| Sonner                       | `IToastService` + `Toaster.razor`           |

### Componentes que precisam de Tailwind CSS

Todos os componentes usam classes Tailwind. Certifica-te de que o Tailwind está configurado no teu projeto:

```bash
# Via libman ou NPM
npm install -D tailwindcss
```

Ou usa o CDN para prototipagem:
```html
<script src="https://cdn.tailwindcss.com"></script>
```

### Variáveis CSS necessárias

Os componentes dependem das variáveis CSS do shadcn/ui. Adiciona ao teu `app.css`:

```css
:root {
  --background: 0 0% 100%;
  --foreground: 222.2 84% 4.9%;
  --primary: 222.2 47.4% 11.2%;
  --primary-foreground: 210 40% 98%;
  --secondary: 210 40% 96.1%;
  --muted: 210 40% 96.1%;
  --muted-foreground: 215.4 16.3% 46.9%;
  --accent: 210 40% 96.1%;
  --accent-foreground: 222.2 47.4% 11.2%;
  --destructive: 0 84.2% 60.2%;
  --border: 214.3 31.8% 91.4%;
  --input: 214.3 31.8% 91.4%;
  --ring: 222.2 84% 4.9%;
  --popover: 0 0% 100%;
  --popover-foreground: 222.2 84% 4.9%;
  --sidebar-background: 0 0% 98%;
  --sidebar-foreground: 240 5.3% 26.1%;
  --sidebar-border: 220 13% 91%;
  --sidebar-accent: 240 4.8% 95.9%;
  --sidebar-accent-foreground: 240 5.9% 10%;
  --sidebar-ring: 217.2 91.2% 59.8%;
}
```
